Wireless Mic Pro Final

What changed:
- Master login persists using localStorage.
- Refresh/reopen does NOT log out.
- Logout button is the only normal way to clear the saved login.
- YouTube Search now shows a song/video result list in the same section.
- Clicking a result plays it inside the embedded YouTube player.
- Play, Pause, and Music Volume send commands to the YouTube iframe player.
- Search uses the existing /api/youtube-search endpoint on your Render app.

Deployment:
Replace the GitHub root index.html with this index.html, commit it,
then in Render choose Manual Deploy -> Deploy latest commit.

Your Render environment should keep YOUTUBE_API_KEY configured.
