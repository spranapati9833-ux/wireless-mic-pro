Wireless Mic Pro - Voice Only / Anti-Echo

Changes:
- Added VOICE ONLY / ANTI-ECHO button.
- Stronger near-voice noise gate.
- Speech-band filtering (140 Hz to 4.2 kHz) to reduce music pickup.
- Compression for clearer close speech.
- Artificial echo path disabled.
- Browser echo cancellation and noise suppression enabled.
- Echo slider disabled by default.

Important physical limitation:
If the Bluetooth speaker is very loud and close to the phone microphone, the phone mic
will physically hear it. A browser cannot perfectly separate that sound from your voice.
Best results: keep speaker 1–2 meters away, point it away from the phone, and keep the phone
5–10 cm from your mouth.

Deploy:
Replace GitHub root index.html with this one, commit, then Render -> Manual Deploy -> Deploy latest commit.
