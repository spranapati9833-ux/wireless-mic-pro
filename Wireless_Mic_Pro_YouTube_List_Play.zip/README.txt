Wireless Mic Pro - Web Version

Open index.html in Chrome/Edge.

Important browser requirements:
- Microphone access requires HTTPS or localhost on most browsers.
- Bluetooth speaker pairing happens in your phone/computer system Bluetooth settings.
- The Output dropdown can route sound to a chosen output only on browsers that support setSinkId().
- YouTube Search opens YouTube search results because direct YouTube playback/search needs the official YouTube API/iframe rules.
- For best live mic monitoring, use headphones or a Bluetooth speaker far enough from the phone to avoid feedback.

Hosting:
Upload the whole folder or ZIP to Netlify, Vercel, Render static site, or any HTTPS hosting.
