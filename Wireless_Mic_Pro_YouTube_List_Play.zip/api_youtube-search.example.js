// Example backend route for /api/youtube-search?q=...
// Set YOUTUBE_API_KEY in your hosting environment.
export default async function handler(req, res) {
  const q = String(req.query?.q || '').trim();
  if (!q) return res.status(400).json({error:'Missing q'});
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) return res.status(500).json({error:'YOUTUBE_API_KEY not configured'});
  const url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=10&q=' + encodeURIComponent(q) + '&key=' + encodeURIComponent(key);
  const r = await fetch(url);
  const data = await r.json();
  res.status(r.status).json(data);
}
