Wireless Mic Pro - Near Voice 5–10 cm Mode

Added:
- Visible "5–10 CM VOICE: ON/OFF" button under MIC ON/OFF.
- Clean mic processing: echo cancellation ON, noise suppression ON.
- Near Voice noise gate: weak/far sounds are strongly reduced.
- Close voice opens the mic quickly, with a short hold so words do not get chopped.

Important:
A phone/web microphone cannot truly measure 5 or 10 centimeters.
This mode estimates "near voice" from signal strength. A loud sound farther away
can still pass the gate, and a very quiet close voice may need to be spoken a bit louder.

Deploy:
Replace GitHub root index.html with this index.html.
Commit changes, then Render -> Manual Deploy -> Deploy latest commit.
