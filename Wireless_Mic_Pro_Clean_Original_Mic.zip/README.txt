Wireless Mic Pro - Clean Original Mic Mode

Default behavior:
- Only microphone speech is prioritized.
- Browser echo cancellation ON.
- Noise suppression ON.
- Auto gain control OFF for a more natural/original mic sound.
- Artificial Echo default = 0%.
- YouTube/music remains on its own playback path.

Important:
A web browser cannot perfectly isolate voice from very loud nearby speaker sound.
For best isolation, keep the Bluetooth speaker a little away from the phone and avoid
pointing the speaker directly at the phone microphone.

Deploy:
Replace GitHub root index.html with this index.html, commit,
then Render -> Manual Deploy -> Deploy latest commit.
