Wireless Mic Pro - Bluetooth Mic Fix

1. Phone Bluetooth settings me speaker/headset connect karein.
2. Website HTTPS par open karein.
3. Mic Phone select karein.
4. MIC ON dabayein aur microphone permission Allow karein.
5. Voice system/Bluetooth output par monitor hogi.
6. Agar browser Audio Output selection support karta hai to dropdown se device choose karein.

Note: Browser Bluetooth speaker ko khud pair/connect force nahi kar sakta. Device pehle phone settings se connect hona chahiye.
